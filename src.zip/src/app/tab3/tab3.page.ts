import { Component } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { addIcons } from 'ionicons';

import { gridOutline } from 'ionicons/icons';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonIcon,
  IonImg,
} from '@ionic/angular/standalone';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';
import Chart from 'chart.js/auto';
import { OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  standalone: true,
  imports: [
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    ExploreContainerComponentModule,
    IonIcon,
    IonImg,
  ],
})
export class Tab3Page implements OnInit {
  @ViewChild('healthGraph', { static: true }) canvas: any;
  chart: any;

  constructor(private storage: Storage) {
    addIcons({ gridOutline });
  }

  events = [3, 4, 1, 4, 5, 2];
  labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  config0: any = {
    type: 'line',
    data: {
      labels: this.labels,
      datasets: [
        {
          label: 'Events hosted',
          data: this.events,
          fill: false,
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1,
        },
      ],
    },
  };

  async ngOnInit() {
    await this.storage.create();
    this.chart = new Chart(this.canvas.nativeElement, this.config0);
  }
}
