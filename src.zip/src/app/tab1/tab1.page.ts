import { Component } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonIcon,
  IonImg,
  IonLabel,
  IonTabButton,
  IonSearchbar,
} from '@ionic/angular/standalone';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';
import { CommonModule } from '@angular/common';

import { addIcons } from 'ionicons';

import { gridOutline } from 'ionicons/icons';

import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    ExploreContainerComponentModule,
    CommonModule,
    IonImg,
    IonIcon,
    IonLabel,
    IonTabButton,
    IonSearchbar,
    RouterLink,
  ],
})
export class Tab1Page {
  constructor() {
    addIcons({ gridOutline });
  }
}
