import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar } from '@ionic/angular/standalone';
declare let google: any;
@Component({
  selector: 'app-map',
  templateUrl: './map.page.html',
  styleUrls: ['./map.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule]
})
export class MapPage implements OnInit, AfterViewInit {

  @ViewChild('map',{static:true}) mapElement: any;
  map: any;

  

  async mapWithPosition(){
    let latLng = await new google.maps.LatLng(-34.9290, 138.6010);
    let mapOptions = {
          center: latLng,
          zoom: 15,
          mapTypeId: google.maps.MapTypeId.ROADMAP
    }
  
    this.map = await new google.maps.Map(this.mapElement.nativeElement, mapOptions);
  } 
  
  async mapWithcurrentPosition(){
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position:any) =>{
         console.log(position.coords.latitude)
         let pos = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
         }
         this.map.setCenter(pos)
      })
        
      } else {
      alert("Geolocation not supported");
      }
  
  }
  
  async mapMarker(){
    let marker = await new google.maps.Marker({
      map: this.map,
      animation: google.maps.Animation.DROP,
      position: this.map.getCenter()
      });
    let infoWindow = new google.maps.InfoWindow({
        content: '<h4>2701ICT Headquarters</h4>'
        });
    google.maps.event.addListener(marker, 'click', () => {
        infoWindow.open(this.map, marker);
    });
  
  
  }

  constructor() { }

  async ngAfterViewInit() {
    await this.mapWithPosition();
  
  }

  async ngOnInit() {
    
    console.log('ngOnInit MapPage');
    
    
  }

  
}
