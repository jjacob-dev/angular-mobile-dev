import { Component } from '@angular/core';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonIcon,
  IonImg,
  IonModal,
  IonItem,
  IonItemSliding,
  IonItemOption,
  IonItemOptions,
  IonButton,
} from '@ionic/angular/standalone';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';
import { Storage } from '@ionic/storage-angular';
import { OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { NgForOf } from '@angular/common';

import { addIcons } from 'ionicons';

import { gridOutline } from 'ionicons/icons';

@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss'],
  standalone: true,
  imports: [
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    ExploreContainerComponentModule,
    IonIcon,
    IonImg,
    IonModal,
    IonItem,
    IonItemSliding,
    IonItemOption,
    IonItemOptions,
    NgForOf,
    IonButton,
  ],
})
export class Tab4Page {
  constructor(private storage: Storage) {
    addIcons({ gridOutline });
  }

  events = [
    {
      eventName: '',
    },
  ];

  editMode = false;
  currentIndex = 0;
  i = '';
  eventName = '';

  defineEvents() {
    console.log('gang shit');
    this.storage.forEach((key, value, index) => {
      this.events = [];
      this.events.push({ eventName: value });
    });
  }

  @ViewChild(IonModal) modal!: IonModal;

  async removeStorage(key: any) {
    await this.storage.remove(key);
  }

  async clearStorage() {
    await this.storage.clear();
    this.events = [];
  }

  async eventDelete(index: any) {
    if (confirm('Delete ' + this.events[index] + '?')) {
      this.removeStorage(index);
      this.events.splice(index, 1);
    }
  }

  async ngOnInit() {
    this.storage.create();
    this.defineEvents();
  }
}
