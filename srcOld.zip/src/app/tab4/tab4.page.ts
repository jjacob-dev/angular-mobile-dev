import { IonModal } from '@ionic/angular';

import { Component, ViewChild, OnInit } from '@angular/core';
@Component({
  selector: 'app-tab4',
  templateUrl: 'tab4.page.html',
  styleUrls: ['tab4.page.scss'],
})
export class Tab4Page {
  constructor() {}

  events = [
    {
      eventName: 'Event 1',
    },
    {
      eventName: 'Event 2',
    },
  ];

  editMode = false;
  currentIndex = 0;
  i = '';
  eventName = '';

  @ViewChild(IonModal) modal!: IonModal;

  eventDelete(index: any) {
    if (confirm('Delete ' + this.events[index] + '?')) {
      this.events.splice(index, 1);
    }
  }
}
